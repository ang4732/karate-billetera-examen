package utils;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Almacén de variables globales compartidas entre escenarios y features.
 *
 * En Karate cada Scenario es independiente (sus variables no pasan al siguiente),
 * por eso los datos generados en el Escenario 1 (usuarios, saldos) y en el
 * Escenario 2 (transacción) se publican aquí para usarlos en los siguientes
 * escenarios y en el feature del Administrador, dentro de la misma ejecución.
 */
public final class VariablesGlobales {

    private static final Map<String, Object> DATOS = new ConcurrentHashMap<>();

    private VariablesGlobales() {
    }

    public static void guardar(String clave, Object valor) {
        if (valor == null) {
            DATOS.remove(clave);
        } else {
            DATOS.put(clave, valor);
        }
    }

    public static Object obtener(String clave) {
        return DATOS.get(clave);
    }

    public static boolean existe(String clave) {
        return DATOS.containsKey(clave);
    }
}
