function fn() {
  var env = karate.env || 'qa';
  karate.log('karate.env =', env);

  // Host del servidor. Se puede sobreescribir con: mvn test -Dapi.host=http://otro-host
  var host = karate.properties['api.host'] || 'http://134.209.211.10';

  var config = {
    env: env,

    // Microservicios (un puerto por servicio, según la documentación de la API)
    authUrl: host + ':4001/auth/v1',
    walletUrl: host + ':4002/wallet/v1',
    transactionUrl: host + ':4003/transaction/v1',
    adminUrl: host + ':4004/admin/v1',

    // Header obligatorio x-channel (REQ-01)
    canalUsuario: 'POSTMAN',
    canalAdmin: 'ADMIN',

    // Data de prueba
    pinUsuarios: '123456',
    montoRecargaEmisor: 1000.00,
    montoRecargaReceptor: 100.00,

    // Credenciales del backoffice (sobreescribibles con -Dadmin.usuario / -Dadmin.clave)
    credencialesAdmin: {
      username: karate.properties['admin.usuario'] || 'admin',
      password: karate.properties['admin.clave'] || 'superpassword'
    },

    // Funciones utilitarias reutilizables
    generarCelular: karate.read('classpath:billetera/utils/generar-celular.js'),
    crearUsuario: karate.read('classpath:billetera/utils/crear-usuario.js')
  };

  // Todas las peticiones de usuario viajan con el header x-channel
  karate.configure('headers', { 'x-channel': config.canalUsuario });
  karate.configure('connectTimeout', 10000);
  karate.configure('readTimeout', 20000);
  karate.configure('logPrettyRequest', true);
  karate.configure('logPrettyResponse', true);

  return config;
}
