package billetera;

import com.intuit.karate.Results;
import com.intuit.karate.Runner;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;

/**
 * Ejecuta toda la automatización en UNA sola ejecución y en orden:
 *   1) Regresión (Escenarios 1, 2 y 3)
 *   2) Flujo Administrador
 *
 * Se usa un solo hilo porque los escenarios dependen de las variables globales
 * generadas por los anteriores.
 *
 * Reporte: target/karate-reports/karate-summary.html
 */
class BilleteraTest {

    @Test
    void ejecutarRegresionCompleta() {
        Results results = Runner.path(
                        "classpath:billetera/features/regresion.feature",
                        "classpath:billetera/features/flujo-administrador.feature")
                .outputCucumberJson(true)
                .parallel(1);

        assertEquals(0, results.getFailCount(), results.getErrorMessages());
    }
}
