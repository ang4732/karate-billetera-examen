function() {
  // Genera un número celular aleatorio de 9 dígitos que inicia en 9 (formato Perú).
  // Ejemplo: 987654321
  var celular = '9';
  for (var i = 0; i < 8; i++) {
    celular += Math.floor(Math.random() * 10);
  }
  return celular;
}
