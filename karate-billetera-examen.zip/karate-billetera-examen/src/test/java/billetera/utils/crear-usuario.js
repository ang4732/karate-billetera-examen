function(rol, celular) {
  // Construye la data de prueba de un usuario de la billetera a partir de su rol y celular.
  return {
    rol: rol,
    phone: celular,
    fullName: 'QA ' + rol + ' Karate',
    email: rol.toLowerCase() + '.' + celular + '@qa.test',
    pin: karate.get('pinUsuarios')
  };
}
