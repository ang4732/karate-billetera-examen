@administrador @parallel=false
Feature: Flujo Administrador - Auditoría de la transferencia

  Desde el Backoffice se valida la transacción realizada en el feature de Regresión,
  usando las variables globales publicadas por sus escenarios.

  Background:
    * def Globales = Java.type('utils.VariablesGlobales')
    * def obtenerGlobal =
      """
      function(clave) {
        var valor = Globales.obtener(clave);
        if (valor == null) karate.fail('No existe la variable global [' + clave + ']. Ejecute primero el feature de Regresión.');
        return valor;
      }
      """
    * def emisor = obtenerGlobal('emisor')
    * def receptor = obtenerGlobal('receptor')
    * def transaccion = obtenerGlobal('transaccion')
    * def saldoFinalEmisor = obtenerGlobal('saldoFinalEmisor')
    * def saldoFinalReceptor = obtenerGlobal('saldoFinalReceptor')
    * configure headers = { 'x-channel': '#(canalAdmin)' }

  @auditoria
  Scenario: Validar la transacción de la operación desde el Backoffice
    # Login del administrador
    Given url adminUrl
    And path 'login'
    And request credencialesAdmin
    When method post
    Then status 200
    And match response contains { token: '#string', type: 'Bearer' }
    * def tokenAdmin = response.token

    # Auditoría de transacciones: la operación debe existir con sus datos correctos
    Given url adminUrl
    And path 'transactions'
    And header Authorization = 'Bearer ' + tokenAdmin
    When method get
    Then status 200
    And match response == '#[_ > 0]'
    * def encontradas = karate.filter(response, function(t){ return t.id == transaccion.transactionId })
    * match encontradas == '#[1]'
    * def operacion = encontradas[0]
    * match operacion.id == transaccion.transactionId
    * match operacion.amount == transaccion.monto
    * match operacion.from == emisor.id
    * match operacion.to == receptor.id

    # Los saldos vistos por el administrador deben coincidir con los de los usuarios
    Given url adminUrl
    And path 'users'
    And header Authorization = 'Bearer ' + tokenAdmin
    When method get
    Then status 200
    * def usuarioEmisor = karate.filter(response, function(u){ return u.id == emisor.id })[0]
    * def usuarioReceptor = karate.filter(response, function(u){ return u.id == receptor.id })[0]
    * match usuarioEmisor contains { status: 'ACTIVE', balance: '#(saldoFinalEmisor)' }
    * match usuarioReceptor contains { status: 'ACTIVE', balance: '#(saldoFinalReceptor)' }
