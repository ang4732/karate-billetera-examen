# Examen Práctico de Karate – Billetera Digital

Automatización de regresión con Karate 1.5.1 sobre la API de la Billetera Enterprise.
Todo corre en **una sola ejecución**, en orden, y cada paso está respaldado por aserciones.

## Requisitos

- Java 17 o superior
- Maven 3.8 o superior
- Acceso de red al servidor `134.209.211.10` (puertos 4001, 4002, 4003 y 4004)

## Cómo ejecutar

```bash
mvn clean test
```

Parámetros opcionales:

| Parámetro | Uso | Valor por defecto |
|---|---|---|
| `-Dapi.host` | Cambiar el host de la API | `http://134.209.211.10` |
| `-Dadmin.usuario` / `-Dadmin.clave` | Credenciales del Backoffice si el docente entregó otras | `admin` / `superpassword` (las de la documentación) |

Ejemplo: `mvn clean test -Dadmin.usuario=admin -Dadmin.clave=OTRA_CLAVE`

## Reporte (y cómo pasarlo a PDF)

Al terminar, Karate genera el reporte HTML en `target/karate-reports/`:

- `karate-summary.html` – resumen de features y escenarios
- `billetera.features.regresion.html` – detalle de los Escenarios 1, 2 y 3
- `billetera.features.flujo-administrador.html` – detalle del Flujo Administrador

Para el PDF: abrir cada archivo en Chrome → `Ctrl + P` → **Guardar como PDF**.

## Estructura

```
src/test/java
├── karate-config.js                      URLs por microservicio, header x-channel, data base
├── logback-test.xml
├── utils/VariablesGlobales.java          Variables globales compartidas entre escenarios/features
└── billetera
    ├── BilleteraTest.java                Runner: ejecuta Regresión y luego Admin (1 hilo)
    ├── features
    │   ├── regresion.feature             Escenarios 1, 2 y 3
    │   └── flujo-administrador.feature   Feature 3: Flujo Administrador
    ├── helpers                           Features reutilizables (@ignore)
    │   ├── registrar-usuario.feature
    │   ├── login.feature
    │   ├── consultar-saldo.feature
    │   └── recargar-saldo.feature
    └── utils
        ├── generar-celular.js            Función de celulares aleatorios (9 dígitos, inicia en 9)
        └── crear-usuario.js              Construye la data de prueba de un usuario
```

## Cómo se cubre cada requisito

| Requisito | Implementación |
|---|---|
| E1.1 Crear Emisor y Receptor | `generarCelular()` + `crearUsuario()` + `POST /auth/v1/register` (201, usuario `ACTIVE`) |
| E1.1 Variables globales | `VariablesGlobales.guardar('emisor', …)` / `obtener(…)` |
| E1.2 Asignar saldo y validarlo | Login + `POST /wallet/v1/deposit`; se valida `newBalance = saldoAnterior + recarga` y que `GET /balance` devuelva lo mismo |
| E1.3 Guardar saldos | `saldoInicialEmisor`, `saldoInicialReceptor` (también dentro de cada usuario global) |
| E1.4 Usuario ya existe | Si el registro responde 409 (`AUTH_006`) el escenario falla con `karate.fail` y mensaje claro |
| E2.1 Login y token | `tokenEmisor` |
| E2.2 Transferencia 450.00 "Pago de Servicios" | `POST /transaction/v1/transfer` |
| E2.3 Validar transacción | 200, `status: COMPLETED`, `transactionId`, `referenceCode` con formato `REF-…` |
| E2.4 Guardar código | `transactionId`, `codigoTransaccion` (+ global `transaccion`) |
| E2.5–6 Saldo Emisor | `saldoActualEmisor == saldoInicialEmisor - 450` |
| E3.1–3 Saldo Receptor | `saldoActualReceptor == saldoInicialReceptor + 450` |
| E3.4–5 Transacciones Receptor | `GET /wallet/v1/transactions`; debe existir exactamente 1 movimiento con el `transactionId` y `referenceCode` del E2, tipo `INCOME` y monto 450 |
| Feature 3 Administrador | `POST /admin/v1/login` + `GET /admin/v1/transactions` (id, monto, origen y destino) + `GET /admin/v1/users` (saldos finales) |

## Conclusiones

- **Independencia de datos:** la suite genera sus propios usuarios con celulares aleatorios, por lo que puede ejecutarse cuantas veces se quiera sin depender de data previa ni limpiarla.
- **Estado compartido controlado:** Karate aísla las variables de cada escenario; para encadenar el flujo (usuarios → transferencia → validaciones) se usó un almacén de variables globales en Java y el runner con un solo hilo y `@parallel=false`, garantizando el orden.
- **Validación por diferencia de saldos:** en lugar de comparar contra valores fijos, se comparan los saldos antes y después de cada operación, lo que hace la prueba robusta ante bonos o saldos iniciales distintos de cero.
- **Fallo temprano y explícito:** si un usuario ya existe o falta una variable global de un escenario previo, la prueba se detiene con un mensaje que indica la causa, facilitando el análisis del reporte.
- **Reutilización:** login, consulta de saldo, recarga y registro están en features helper, lo que reduce duplicidad y deja los escenarios legibles como especificación del negocio.
- **Doble verificación:** la transacción se valida desde tres puntos de vista (respuesta de la transferencia, historial del Receptor y auditoría del Administrador), lo que da mayor confianza de que la operación quedó registrada de forma consistente.
