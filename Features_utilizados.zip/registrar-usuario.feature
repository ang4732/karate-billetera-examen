@ignore
Feature: Helper - Registrar un usuario nuevo en la billetera

  Scenario: Registrar usuario
    Given url authUrl
    And path 'register'
    And request { phone: '#(usuario.phone)', fullName: '#(usuario.fullName)', email: '#(usuario.email)', pin: '#(usuario.pin)' }
    When method post
    # Si el celular ya está registrado (409 / AUTH_006) el escenario debe caerse con un error claro
    * if (responseStatus == 409) karate.fail('El usuario ' + usuario.rol + ' con celular ' + usuario.phone + ' YA EXISTE (' + response.code + '). Se esperaba registrar un usuario nuevo.')
    Then status 201
    And match response contains { message: '#string', user: '#object' }
    And match response.user contains { id: '#string', status: 'ACTIVE' }
    * def usuarioId = response.user.id
