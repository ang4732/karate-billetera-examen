@ignore
Feature: Helper - Iniciar sesión con celular y PIN

  Scenario: Login de usuario
    Given url authUrl
    And path 'login'
    And request { phone: '#(phone)', pin: '#(pin)' }
    When method post
    Then status 200
    And match response contains { token: '#string', user: '#object' }
    And match response.user contains { id: '#string' }
    * def token = response.token
    * def usuario = response.user
