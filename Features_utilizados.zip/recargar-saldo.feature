@ignore
Feature: Helper - Recargar saldo al usuario autenticado

  Background:
    * def consultarSaldo = read('classpath:billetera/helpers/consultar-saldo.feature')

  Scenario: Recargar saldo y consultar el resultado
    # Saldo antes de la recarga
    * def consultaAntes = call consultarSaldo { token: '#(token)' }
    * def saldoAnterior = consultaAntes.saldo

    # Recarga
    Given url walletUrl
    And path 'deposit'
    And header Authorization = 'Bearer ' + token
    And request { amount: '#(monto)' }
    When method post
    Then status 200
    And match response contains { success: true, newBalance: '#number' }
    * def saldoNuevo = response.newBalance

    # Saldo después de la recarga (consulta independiente)
    * def consultaDespues = call consultarSaldo { token: '#(token)' }
    * def saldoConsultado = consultaDespues.saldo
