@regresion @parallel=false
Feature: Regresion - Billetera Digital

  Flujo de regresión end-to-end que genera su propia data de prueba:
  registra un usuario Emisor y un Receptor, les asigna saldo, transfiere
  450.00 del Emisor al Receptor y valida saldos e historial de ambos.
  Los escenarios comparten datos mediante variables globales (utils.VariablesGlobales)
  y se ejecutan en orden dentro de una sola ejecución.

  Background:
    * def Globales = Java.type('utils.VariablesGlobales')
    * def obtenerGlobal =
      """
      function(clave) {
        var valor = Globales.obtener(clave);
        if (valor == null) karate.fail('No existe la variable global [' + clave + ']. El escenario previo no se ejecutó o falló.');
        return valor;
      }
      """
    * def registrarUsuario = read('classpath:billetera/helpers/registrar-usuario.feature')
    * def login = read('classpath:billetera/helpers/login.feature')
    * def consultarSaldo = read('classpath:billetera/helpers/consultar-saldo.feature')
    * def recargarSaldo = read('classpath:billetera/helpers/recargar-saldo.feature')
    * def montoTransferencia = 450.00
    * def notaTransferencia = 'Pago de Servicios'

  @registro
  Scenario: Escenario 1 - Registro de usuarios Emisor y Receptor con saldo asignado
    # 1. Generar data de prueba con celulares aleatorios
    * def emisor = crearUsuario('Emisor', generarCelular())
    * def receptor = crearUsuario('Receptor', generarCelular())
    * match emisor.phone == '#regex 9[0-9]{8}'
    * match receptor.phone == '#regex 9[0-9]{8}'
    * match emisor.phone != receptor.phone

    # 1.1 Registrar ambos usuarios (si alguno ya existe, el escenario se cae con error)
    * def registroEmisor = call registrarUsuario { usuario: '#(emisor)' }
    * def registroReceptor = call registrarUsuario { usuario: '#(receptor)' }
    * set emisor.id = registroEmisor.usuarioId
    * set receptor.id = registroReceptor.usuarioId
    * match emisor.id != receptor.id

    # 2. Asignar saldo suficiente a cada usuario y validar que se asignó correctamente
    * def sesionEmisor = call login { phone: '#(emisor.phone)', pin: '#(emisor.pin)' }
    * def recargaEmisor = call recargarSaldo { token: '#(sesionEmisor.token)', monto: '#(montoRecargaEmisor)' }
    * match recargaEmisor.saldoNuevo == recargaEmisor.saldoAnterior + montoRecargaEmisor
    * match recargaEmisor.saldoConsultado == recargaEmisor.saldoNuevo
    * assert recargaEmisor.saldoConsultado >= montoTransferencia

    * def sesionReceptor = call login { phone: '#(receptor.phone)', pin: '#(receptor.pin)' }
    * def recargaReceptor = call recargarSaldo { token: '#(sesionReceptor.token)', monto: '#(montoRecargaReceptor)' }
    * match recargaReceptor.saldoNuevo == recargaReceptor.saldoAnterior + montoRecargaReceptor
    * match recargaReceptor.saldoConsultado == recargaReceptor.saldoNuevo

    # 3. Guardar los saldos actuales de cada usuario en variables
    * def saldoInicialEmisor = recargaEmisor.saldoConsultado
    * def saldoInicialReceptor = recargaReceptor.saldoConsultado
    * set emisor.saldoInicial = saldoInicialEmisor
    * set receptor.saldoInicial = saldoInicialReceptor

    # Publicar usuarios y saldos como variables globales para los siguientes escenarios
    * Globales.guardar('emisor', emisor)
    * Globales.guardar('receptor', receptor)
    * karate.log('EMISOR   ->', emisor.phone, '| id:', emisor.id, '| saldo inicial:', saldoInicialEmisor)
    * karate.log('RECEPTOR ->', receptor.phone, '| id:', receptor.id, '| saldo inicial:', saldoInicialReceptor)

  @transferencia
  Scenario: Escenario 2 - Transferencia del usuario Emisor al Receptor
    * def emisor = obtenerGlobal('emisor')
    * def receptor = obtenerGlobal('receptor')

    # 1. Login del Emisor y guardar el token en una variable
    * def sesionEmisor = call login { phone: '#(emisor.phone)', pin: '#(emisor.pin)' }
    * def tokenEmisor = sesionEmisor.token
    * match sesionEmisor.usuario.id == emisor.id

    # Categoría de gasto para clasificar el pago
    Given url walletUrl
    And path 'categories'
    And header Authorization = 'Bearer ' + tokenEmisor
    When method get
    Then status 200
    And match response == '#[_ > 0]'
    * def categoriasGasto = karate.filter(response, function(c){ return c.type == 'EXPENSE' })
    * match categoriasGasto == '#[_ > 0]'
    * def categoria = categoriasGasto[0]

    # 2. Transferencia de 450.00 con la nota "Pago de Servicios"
    Given url transactionUrl
    And path 'transfer'
    And header Authorization = 'Bearer ' + tokenEmisor
    And request { recipientId: '#(receptor.id)', amount: '#(montoTransferencia)', description: '#(notaTransferencia)', categoryId: '#(categoria.id)' }
    When method post

    # 3. Validar la transacción
    Then status 200
    And match response contains { transactionId: '#string', referenceCode: '#string', status: 'COMPLETED', message: '#string' }
    And match response.referenceCode == '#regex REF-[0-9]+'

    # 4. Guardar el código de la transacción en una variable (y como variable global)
    * def transactionId = response.transactionId
    * def codigoTransaccion = response.referenceCode
    * def transaccion = { transactionId: '#(transactionId)', referenceCode: '#(codigoTransaccion)', monto: '#(montoTransferencia)', nota: '#(notaTransferencia)' }
    * Globales.guardar('transaccion', transaccion)
    * karate.log('TRANSACCION ->', transactionId, '| código:', codigoTransaccion)

    # 5. Consultar el saldo del Emisor
    * def consultaEmisor = call consultarSaldo { token: '#(tokenEmisor)' }
    * def saldoActualEmisor = consultaEmisor.saldo

    # 6. Validar la disminución del saldo respecto al saldo inicial (Escenario 1, paso 3)
    * def saldoEsperadoEmisor = emisor.saldoInicial - montoTransferencia
    * match saldoActualEmisor == saldoEsperadoEmisor
    * assert saldoActualEmisor < emisor.saldoInicial
    * Globales.guardar('saldoFinalEmisor', saldoActualEmisor)

  @validacion-receptor
  Scenario: Escenario 3 - Validación de la transferencia en el Receptor
    * def receptor = obtenerGlobal('receptor')
    * def transaccion = obtenerGlobal('transaccion')

    # 1. Login del Receptor y guardar el token en una variable
    * def sesionReceptor = call login { phone: '#(receptor.phone)', pin: '#(receptor.pin)' }
    * def tokenReceptor = sesionReceptor.token
    * match sesionReceptor.usuario.id == receptor.id

    # 2. Consultar el saldo del Receptor
    * def consultaReceptor = call consultarSaldo { token: '#(tokenReceptor)' }
    * def saldoActualReceptor = consultaReceptor.saldo

    # 3. Validar el incremento respecto al saldo inicial (Escenario 1, paso 3)
    * def saldoEsperadoReceptor = receptor.saldoInicial + montoTransferencia
    * match saldoActualReceptor == saldoEsperadoReceptor
    * assert saldoActualReceptor > receptor.saldoInicial
    * Globales.guardar('saldoFinalReceptor', saldoActualReceptor)

    # 4. Consultar las transacciones del Receptor
    Given url walletUrl
    And path 'transactions'
    And header Authorization = 'Bearer ' + tokenReceptor
    When method get
    Then status 200
    And match response == '#[_ > 0]'

    # 5. Validar el número de transacción contra el del Escenario 2, paso 4
    * def movimientos = karate.filter(response, function(m){ return m.referenceCode == transaccion.referenceCode && m.type == 'INCOME' })
    * match movimientos == '#[1]'
    * def movimiento = movimientos[0]
    * match movimiento.referenceCode == transaccion.referenceCode
    * match movimiento.type == 'INCOME'
    * match movimiento.amount == montoTransferencia
