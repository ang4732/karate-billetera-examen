@ignore
Feature: Helper - Consultar el saldo del usuario autenticado

  Scenario: Consultar saldo
    Given url walletUrl
    And path 'balance'
    And header Authorization = 'Bearer ' + token
    When method get
    Then status 200
    And match response contains { balance: '#number', currency: '#string' }
    * def saldo = response.balance
